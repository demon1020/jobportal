-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 24, 2023 at 05:23 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sql12656260`
--

-- --------------------------------------------------------

--
-- Table structure for table `jobnames`
--

CREATE TABLE `jobnames` (
  `id` int(11) NOT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `createdAt` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedAt` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobnames`
--

INSERT INTO `jobnames` (`id`, `job_title`, `createdAt`, `updatedAt`) VALUES
(51, 'Software Developer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(52, 'Data Analyst', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(53, 'Project Manager', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(54, 'Marketing Specialist', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(55, 'Graphic Designer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(56, 'Sales Representative', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(57, 'Accountant', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(58, 'Customer Support Spe', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(59, 'UX/UI Designer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(60, 'Network Administrator', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(61, 'HR Manager', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(62, 'Financial Analyst', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(63, 'Content Writer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(64, 'Product Manager', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(65, 'Systems Engineer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(66, 'Civil Engineer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(67, 'Registered Nurse', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(68, 'Pharmacist', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(69, 'Electrician', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(70, 'Mechanical Engineer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(71, 'Teacher', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(72, 'Lawyer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(73, 'Chef', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(74, 'Dental Hygienist', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(75, 'Veterinarian', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(76, 'Architect', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(77, 'Librarian', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(78, 'Police Officer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(79, 'Firefighter', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(80, 'Database Administrator', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(81, 'IT Support Specialist', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(82, 'Cybersecurity Analyst', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(83, 'DevOps Engineer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(84, 'Front-end Developer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(85, 'Back-end Developer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(86, 'Full-stack Developer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(87, 'Cloud Solutions Architect', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(88, 'UI/UX Designer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(89, 'Quality Assurance Engineer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(90, 'Machine Learning Engineer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(91, 'IT Manager', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(92, 'Business Intelligence', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(93, 'Web Developer', '2023-10-24 12:19:56', '2023-10-24 12:20:07'),
(94, 'Database Developer', '2023-10-24 12:19:56', '2023-10-24 12:20:07');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `elapsedString` varchar(255) DEFAULT NULL,
  `isFavourite` tinyint(1) DEFAULT NULL,
  `isFixedPrice` tinyint(1) DEFAULT NULL,
  `isOnSite` tinyint(1) DEFAULT NULL,
  `isPaymentVerified` tinyint(1) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `maxPrice` decimal(10,2) DEFAULT NULL,
  `minPrice` decimal(10,2) DEFAULT NULL,
  `postedOn` datetime DEFAULT NULL,
  `priceUnit` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `company`, `elapsedString`, `isFavourite`, `isFixedPrice`, `isOnSite`, `isPaymentVerified`, `location`, `maxPrice`, `minPrice`, `postedOn`, `priceUnit`, `createdAt`, `updatedAt`) VALUES
(1, 'Web Developer', 'Tech mahi', 'Close in 4 days', 0, 1, 1, 0, 'United States', 30000.00, 25000.00, '2023-10-22 12:00:00', 'month', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'Data Analyst', 'Tech mahi', 'Close in 4 days', 0, 1, 1, 0, 'United States', 30000.00, 25000.00, '2023-10-22 12:00:00', 'month', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 'Software Engineer', 'Tech Innovations', 'Close in 5 days', 1, 0, 1, 1, 'Canada', 45000.00, 35000.00, '2023-10-21 14:30:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(4, 'Marketing Specialist', 'Bright Marketing', 'Close in 3 days', 1, 0, 0, 1, 'United Kingdom', 40000.00, 30000.00, '2023-10-19 09:15:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'Financial Analyst', 'Finance Corp', 'Close in 2 days', 0, 1, 0, 0, 'United States', 75000.00, 65000.00, '2023-10-18 16:45:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'Graphic Designer', 'Design Studios', 'Close in 6 days', 1, 0, 0, 1, 'Canada', 35000.00, 25000.00, '2023-10-17 11:20:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'Accountant', 'Financial Pros', 'Close in 4 days', 0, 1, 1, 0, 'United States', 60000.00, 50000.00, '2023-10-16 15:40:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'Project Manager', 'Project Solutions', 'Close in 7 days', 0, 1, 1, 0, 'United Kingdom', 55000.00, 45000.00, '2023-10-15 10:10:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'Network Administrator', 'Tech Networks', 'Close in 5 days', 0, 1, 1, 0, 'United States', 70000.00, 60000.00, '2023-10-14 17:30:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'HR Manager', 'HR Solutions', 'Close in 6 days', 0, 1, 1, 0, 'Canada', 48000.00, 38000.00, '2023-10-13 12:05:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'Content Writer', 'Content Creations', 'Close in 3 days', 1, 0, 0, 1, 'United States', 32000.00, 22000.00, '2023-10-12 14:55:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'Product Manager', 'Product Innovations', 'Close in 4 days', 0, 1, 1, 0, 'United States', 67000.00, 57000.00, '2023-10-11 10:45:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'Systems Engineer', 'Systems Solutions', 'Close in 2 days', 1, 0, 0, 1, 'United Kingdom', 58000.00, 48000.00, '2023-10-10 16:25:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'Civil Engineer', 'Engineering Corp', 'Close in 3 days', 0, 1, 1, 0, 'Canada', 52000.00, 42000.00, '2023-10-09 12:30:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'Registered Nurse', 'Healthcare Solutions', 'Close in 5 days', 1, 0, 1, 1, 'United States', 75000.00, 65000.00, '2023-10-08 09:10:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'Pharmacist', 'PharmaCare', 'Close in 6 days', 0, 1, 1, 0, 'United Kingdom', 70000.00, 60000.00, '2023-10-07 14:40:00', 'year', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone_number` int(11) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `phone_number`, `createdAt`, `updatedAt`) VALUES
(1, 'asdf', '123@gmail.com', 'asdf', 1234, '2023-10-24 08:39:59', '2023-10-24 08:39:59'),
(3, 'babu', 'babunabik@gmail.com', 'Babu@123', 1234, '2023-10-24 08:40:36', '2023-10-24 08:40:36'),
(8, 'babu', 'babu@gmail.com', 'Babu@123', 1234, '2023-10-24 08:53:43', '2023-10-24 08:53:43'),
(10, 'babua', 'babu@gmail.comq', 'Babu@123', 1234, '2023-10-24 09:03:01', '2023-10-24 09:03:01'),
(11, 'babu2vv', 'babub@gmail.com', 'Babu@123', 1234567890, '2023-10-24 14:24:11', '2023-10-24 14:24:11'),
(12, 'babu2vvv', 'babxub@gmail.com', 'Babu@123', 1234567890, '2023-10-24 14:25:10', '2023-10-24 14:25:10'),
(13, 'babu2vvvf', 'bdbxub@gmail.com', 'Babu@123', 1234567890, '2023-10-24 14:26:34', '2023-10-24 14:26:34'),
(14, 'babu2vvvfg', 'gdbxub@gmail.com', 'Babu@123', 1234567890, '2023-10-24 14:29:05', '2023-10-24 14:29:05'),
(15, 'basbu', 'basbu@gmail.com', 'Babu@123', 1234, '2023-10-24 14:30:35', '2023-10-24 14:30:35'),
(16, 'babud2vvvfg', 'gdgbxub@gmail.com', 'Babu@123', 1234567890, '2023-10-24 14:30:52', '2023-10-24 14:30:52'),
(17, 'babudd2vvvfg', 'gdrgbxub@gmail.com', 'Babu@123', 1234567890, '2023-10-24 14:32:05', '2023-10-24 14:32:05'),
(18, 'babudddd2vvvfg', 'gfdrxfgbxub@gmail.com', 'Babu@123', 1234567890, '2023-10-24 14:38:50', '2023-10-24 14:38:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jobnames`
--
ALTER TABLE `jobnames`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jobnames`
--
ALTER TABLE `jobnames`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
